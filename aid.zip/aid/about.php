<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>About Page</title>
  <?php
  include ('includes/layout.php');
  ?>
  <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
  
  
</head>
<body>
 <?php
 include ('includes/header.php');
 ?>
 <section id="about-us">

  <div class="container">
    <div class="theme-title">
      <div class="page-middle-banner">
        <div class="opacity">

          <h3>About Me</h3>
          <p><b>You can know me as a person.you can find out about my background,eduction and more below.</b></p>
          <a href="contact.php" class="hvr-bounce-to-right">Let's Work Together</a>
        </div> <!-- /.opacity -->
      </div> <!-- /.page-middle-banner -->
      <h2>About Me</h2>
      <p> My name is Shweta Shrestha.I'm the Web Developer and Web Desiger.I understand the challenges of working remotely.I value my time and other time and always aim to work efficiently.I understand the important stay in organized while working and also important of good communication skills.</p> <br/>
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6">
          <div class="single-about-content">
            <div class="icon round-border tran3s">
              <i style='font-size:24px' class='fas'>&#xf2a3;</i>
            </div>
            <h5><a href="contact.php" class="tran3s">Communication</a></h5>
            <p>I know the importance of good communications skills</p>
            
          </div> <!-- /.single-about-content -->
        </div>
        
        <div class="col-lg-3 col-md-3 col-sm-6">
          <div class="single-about-content">
            <div class="icon round-border tran3s">
              <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
            </div>
            <h5><a href="contact.php" class="tran3s">Web Development</a></h5>
            <p>I'm study of computer science and recognize the importance afflying proper software development techniques to web application.</p>
            
            
          </div> 
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6">
          <div class="single-about-content">
            <div class="icon round-border tran3s">
              <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
            </div>
            <h5><a href="contact.php" class="tran3s">Web Design</a></h5>
            <p>I'm confortable using Photoshop ans Sketch and can take designs from mock-up implementation in this portfolio</p>
            
            
          </div> 
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6">
          <div class="single-about-content">
            <div class="icon round-border tran3s">
              <i style='font-size:24px' class='fas'>&#xf53f;</i>
            </div>
            <h5><a href="contact.php" class="tran3s">Collaboration</a></h5>
            <p>I like to working in the team.I'm happy to integrate into your exting team to help get your project implemented.</p>
            
            
          </div> 
        </div>
        
        
      </div>


      <h1 style="text-align: center;">Education</h1>
      <div id="pricing-section">
        <div class="container">
          <div class="clear-fix">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="single-price-table hvr-float-shadow">
                <h4>Bachelor Degree</h4>

                <p>The British College</p>                
                
                
              </div> <!-- /.single-price-table -->
            </div> <!-- /.col -->

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="single-price-table hvr-float-shadow">
                <h4>High School</h4>
                <p>Cambridge College</p>
                

              </div> <!-- /.single-price-table -->
            </div> <!-- /.col -->

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="single-price-table hvr-float-shadow">
                <h4>School</h4>
                <p>Pushpasadan Boarding High School</p>
                
              </div> <!-- /.single-price-table -->
            </div> <!-- /.col -->
          </div>
        </div> <!-- /.container -->
      </div> <!-- /#pricing-section -->
      <br/><br/>
      


      <h3>See the working i have done in Portifolio</h3>

      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6">
          <div class="single-about-content">
            <div class="icon round-border tran3s">
              <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
            </div>
            <h5><a href="#" class="tran3s">Web Development</a></h5>
            <p>I am web Developer. i have worked in PHP,PHP with OOP and Larvel Framework</p>
            <a href="project.php" class="more tran3s hvr-bounce-to-right">More Details</a>
          </div> 
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6">
          <div class="single-about-content">
            <div class="icon round-border tran3s">
              <i class="fa fa-camera" aria-hidden="true"></i>
            </div>
            <h5><a href="#" class="tran3s">PHOTOGRAPHY</a></h5>
            <p>I like to take photography of the natrual resource.</p>
            <a href="project.php" class="more tran3s hvr-bounce-to-right">More Details</a>
          </div> <!-- /.single-about-content -->
        </div> <!-- /.col -->

        <div class="col-lg-3 col-md-3 col-sm-6">
          <div class="single-about-content">
            <div class="icon round-border tran3s">
              <i class="fa fa-life-ring" aria-hidden="true"></i>
            </div>
            <h5><a href="#" class="tran3s">Digital Media</a></h5>
            <p>Lorem ipsum dolor sit amet, consect et adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
            <a href="project.php" class="more tran3s hvr-bounce-to-right">More Details</a>
          </div> <!-- /.single-about-content -->
        </div> <!-- /.col -->

        <div class="col-lg-3 col-md-3 col-sm-6">
          <div class="single-about-content">
            <div class="icon round-border tran3s">
              <i class="fa fa-line-chart" aria-hidden="true"></i>
            </div>
            <h5><a href="#" class="tran3s">Online Marketing</a></h5>
            <p>Lorem ipsum dolor sit amet, consect et adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna.</p>
            <a href="project.php" class="more tran3s hvr-bounce-to-right">More Details</a>
          </div> <!-- /.single-about-content -->
        </div> <!-- /.col -->
      </div>
    </div>
  </section>



</body>
</html>