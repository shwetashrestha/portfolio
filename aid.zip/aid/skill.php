<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Skill Page</title>
	<?php
	include ('includes/layout.php');
	?>
</head>
<body>

	<?php
	include ('includes/header.php');
	?>
		<!--
			=====================================================
				Page middle banner
			=====================================================
		-->

		<div class="page-middle-banner">
			<div class="opacity">
				<!-- <h3>We Create Creative <span class="p-color">&amp;</span> Best Unique Design</h3> -->
				<h3>I am Determine <span class="p-color">&amp;</span> Hard working</h3>
				<a href="contact.php" class="hvr-bounce-to-right">Let's Work Together</a>
			</div> <!-- /.opacity -->
		</div> <!-- /.page-middle-banner --><br/><br/>
<!--
			=====================================================
				Skill Section
			=====================================================
		-->
		<h1 style="text-align: center;"> My Skills</h1>
		<div id="skill-section">
			<div class="clear-fix">
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<div class="img"><img src="images/home/2.jpg" alt="Image"></div>
				
				</div> <!-- /.col- -->

				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<div class="skills-progress skills">
						<div class="habilidades_contenedor">
							<div class="codeconSkills">
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea">HTML</span>
									</div>
									<div class="skillBar" data-percent="80%">
										<br/>
										<span class="PercentText">80%</span>
									</div>
								</div>
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea ">CSS</span>

									</div>
									<div class="skillBar" data-percent="75%">
										<span class="PercentText">75%</span>
									</div>
								</div>
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea">
											Java Script
										</span>

									</div>
									<div class="skillBar" data-percent="50%">
										<span class="PercentText">50%</span>
									</div>
								</div>
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea">
											 jQuery
										</span>

									</div>
									<div class="skillBar" data-percent="50%">
										<span class="PercentText">50%</span>
									</div>
								</div>
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea">
											AJAX
										</span>

									</div>
									<div class="skillBar" data-percent="50%">
										<span class="PercentText">50%</span>
									</div>
								</div>
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea">SQL</span>

									</div>
									<div class="skillBar" data-percent="45%">
										<span class="PercentText">45%</span>
									</div>
								</div>
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea">PHP</span>

									</div>
									<div class="skillBar" data-percent="65%">
										<span class="PercentText ">65%</span>
									</div>
								</div>
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea">PHP with OOP</span>

									</div>
									<div class="skillBar" data-percent="65%">
										<span class="PercentText ">45%</span>
									</div>
								</div>
								<div class="codeconSkillbar">
									<div class="skill-text">
										<span class="codeconSkillArea">Laravel Framework</span>

									</div>
									<div class="skillBar" data-percent="65%">
										<span class="PercentText ">30%</span>
									</div>
								</div>
								</div> <!-- /.codeconSkills
							</div> <!-- /.habilidades_contenedor -->
						</div> <!-- /.skills-progress -->
					</div>
				</div> <!-- /.clear-fix -->
			</div> <!-- /.container -->
		</div>

		<?php
		include ('includes/footer.php');
		?>



	</body>
	</html>
