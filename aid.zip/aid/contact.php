<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Contact Page</title>
	<?php
	include ('includes/layout.php');
	?>
</head>
<body>

	<?php
	include ('includes/header.php');
	?>

	<!--
			=====================================================
				Contact Section
			=====================================================
		-->
		<div id="contact-section">
			<div class="container">
				<div class="clear-fix contact-address-content">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="left-side">
							<h2>Contact </h2>
							<p>Have a question or want to work together?</p>

							<ul>
								<li>
									<div class="icon tran3s round-border p-color-bg"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
									<h6>Address</h6>
									<p>Kirtipur,Kathmandu</p>
								</li>
								<li>
									<div class="icon tran3s round-border p-color-bg"><i class="fa fa-phone" aria-hidden="true"></i></div>
									<h6>Phone</h6>
									<p>+977 9813124345</p>
								</li>
								<li>
									<div class="icon tran3s round-border p-color-bg"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>
									<h6>Email</h6>
									<p>shwetashrestha7@gmail.com</p>
								</li>
							</ul>
						</div> <!-- /.left-side -->
					</div> <!-- /.col- -->


					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="map-area">
							<h2>Location</h2>
							<div id="map">
								<iframe width="600" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=panga party venue&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
							</div>
						</div> <!-- /.map-area -->
					</div> <!-- /.col- -->
				</div> <!-- /.contact-address-content -->

				<!-- Contact Form -->
				<div class="send-message">
					<h2>Send Message</h2>

					<form action="inc/sendemail.php" class="form-validation" autocomplete="off" method="post">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
								<div class="single-input">
									<input type="text" placeholder="First Name*" name="Fname">
								</div> <!-- /.single-input -->
							</div>
							<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
								<div class="single-input">
									<input type="text" placeholder="Last Name*" name="Lname">
								</div> <!-- /.single-input -->
							</div>
							<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
								<div class="single-input">
									<input type="email" placeholder="Your Email*" name="email">
								</div> <!-- /.single-input -->
							</div>
						</div> <!-- /.row -->
						<div class="single-input">
							<input type="text" placeholder="Subject" name="sub">
						</div> <!-- /.single-input -->
						<textarea placeholder="Write Message" name="message"></textarea>


						<button class="tran3s p-color-bg">Send Message</button>
					</form>


					<!-- Contact Form Validation Markup -->
					<!-- Contact alert -->
					<div class="alert-wrapper" id="alert-success">
						<div id="success">
							<button class="closeAlert"><i class="fa fa-times" aria-hidden="true"></i></button>
							<div class="wrapper">
								<p>Your message was sent successfully.</p>
							</div>
						</div>
					</div> <!-- End of .alert_wrapper -->
					<div class="alert-wrapper" id="alert-error">
						<div id="error">
							<button class="closeAlert"><i class="fa fa-times" aria-hidden="true"></i></button>
							<div class="wrapper">
								<p>Sorry!Something Went Wrong.</p>
							</div>
						</div>
					</div> <!-- End of .alert_wrapper -->
				</div> <!-- /.send-message -->
			</div> <!-- /.container -->
		</div> <!-- /#contact-section -->
<!-- 		<?php

    $admin_email = "shwetashrestha7@gmail.com"; //your email
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $msg = $_POST['msg'];
    $header = "From:" . $email;
    $exe =  mail($admin_email, "$subject", $msg, $header);


    if($exe){
    	echo "<script>alert('Your Messege Has Been Sent.');
    
    	</script>";

    }
    ?> -->
    <?php
    include ('includes/footer.php');
    ?>



</body>
</html>
