<!--
			=====================================================
				Our Client
			=====================================================
			-->
			<div id="our-client">
				<div class="container">
					<div class="theme-title">
						<h2>OUR HAPPY CLIENTS</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type.</p>
					</div> <!-- /.theme-title -->

					<div class="client-slider">
						<div class="item">
							<img src="images/home/c1.jpg" alt="Client">
							<p>Our successful construction approach is based on aggressive subcontractor administration, employ-ment of competent personnel, accurate schedule control, quality control and cost control. We employ only qualified subcontractors who share our goal in creating quality projects.</p>
							<h6>- Spryte Loriano -</h6>
						</div> <!-- /.item -->
						<div class="item">
							<img src="images/home/c2.jpg" alt="Client">
							<p>Our successful construction approach is based on aggressive subcontractor administration, employ-ment of competent personnel, accurate schedule control, quality control and cost control. We employ only qualified subcontractors who share our goal in creating quality projects.</p>
							<h6>- Spryte Loriano -</h6>
						</div> <!-- /.item -->
						<div class="item">
							<img src="images/home/c3.jpg" alt="Client">
							<p>Our successful construction approach is based on aggressive subcontractor administration, employ-ment of competent personnel, accurate schedule control, quality control and cost control. We employ only qualified subcontractors who share our goal in creating quality projects.</p>
							<h6>- Spryte Loriano -</h6>
						</div> <!-- /.item -->
					</div> <!-- /.client-slider -->
				</div> <!-- /.container -->
			</div> <!-- /#our-client -->

			