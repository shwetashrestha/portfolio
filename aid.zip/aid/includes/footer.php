<!-- Scroll Top Button -->
			<button class="scroll-top tran3s p-color-bg">
				<i class="fa fa-long-arrow-up" aria-hidden="true"></i>
			</button>

<!--
			=====================================================
				Footer
			=====================================================
			-->
			<footer>
				<div class="container">
					<a href="index.php" class="logo"><img src="images/logo/logo1.png" alt="Logo" width="100px" height="50px"></a>

					<ul>
						<li><a href="https://www.facebook.com/shweta.shrestha.165" class="tran3s round-border"  target="_black"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="https://twitter.com/ShwetaShrestha8" class="tran3s round-border" target="_black"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<!-- <li><a href="#" class="tran3s round-border"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li> -->
						<li><a href="https://www.linkedin.com/in/shweta-shrestha-3681a1140/" target="_black" class="tran3s round-border"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
						<!-- <li><a href="#" class="tran3s round-border"><i class="fa fa-skype" aria-hidden="true"></i></a></li> -->
						<!-- <li><a href="#" class="tran3s round-border"><i class="fa fa-flickr" aria-hidden="true"></i></a></li>
						<li><a href="#" class="tran3s round-border"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						<li><a href="#" class="tran3s round-border"><i class="fa fa-rss" aria-hidden="true"></i></a></li> -->
					</ul>
					<p>Copyright @2018 All rights reserved <i class="fa fa-heart-o" aria-hidden="true"> </i> by <a href="#" target="_blank">Shweta Shrestha</a></p>
				</div>
			</footer>
